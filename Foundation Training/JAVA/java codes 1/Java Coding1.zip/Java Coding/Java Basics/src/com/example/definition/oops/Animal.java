package com.example.definition.oops;

public class Animal {
	
	private String name;
	private int legs;
	private boolean canFly;
	
}


/*
 * All The animals -> Dogs, Cats, Lions 
 * 
 * Animal animal = new Animal();
 * Animal dog = new Animal();
 * Animal cat = new Animal();
 * 
 * */
