package com.example.basic.data.types;

public class Person {
	
	public String personName="James";
	public final int PERSON_AGE=25;

}
