package com.example.basic.comments.package_calling;

import com.example.basic.comments.Comments;

public class PackageCalling {
	
	
	public static void main(String[] args) {
		
		Comments comment = new Comments();
		comment.add(2, 5);
		
		
	}

}
