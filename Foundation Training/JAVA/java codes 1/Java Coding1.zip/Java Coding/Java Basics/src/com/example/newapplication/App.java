package com.example.newapplication;

public class App {
	
	
	/*
	 * Project -> main function -> JVM runs the main function
	 * If there is no main function then that class/project is not runnable
	 * 
	 * */
	
	public static void main(String[] args) {
		print();
	}
	
	public static void print() {
		System.out.println("Hi");
	}
	
	public void display() {
		System.out.println("App Class");
	}
	
	private void say(){
		System.out.println("Say");
	}

}
