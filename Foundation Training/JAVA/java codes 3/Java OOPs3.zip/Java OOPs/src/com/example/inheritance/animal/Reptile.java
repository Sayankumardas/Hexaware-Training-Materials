package com.example.inheritance.animal;


/*
 * TODO: Write the functionality on your own
 * 
 * */

public class Reptile {

}
