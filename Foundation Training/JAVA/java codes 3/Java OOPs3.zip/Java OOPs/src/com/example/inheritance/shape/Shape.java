package com.example.inheritance.shape;

public class Shape {

}
