
public class Main {
	
	static int x[];
	
	static {
		x[0]=1;
	}

	public static void main(String[] args) {
		
	}
}
