
public class Derived extends Base {

}
