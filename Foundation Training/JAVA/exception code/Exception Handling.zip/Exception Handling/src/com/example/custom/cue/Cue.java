package com.example.custom.cue;

public class Cue {
	
	int pieces;
	boolean retain;
	
	public Cue(int pieces, boolean retain) {
		this.pieces = pieces;
		this.retain = retain;
	}

}
