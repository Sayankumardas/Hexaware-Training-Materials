package com.example.custom.cue;

public class CueException extends Exception {
	
	public CueException(String msg) {
		super(msg);
	}

}
