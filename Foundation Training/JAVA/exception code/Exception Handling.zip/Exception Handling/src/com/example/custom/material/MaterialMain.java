package com.example.custom.material;

public class MaterialMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Material m = new Material(0,32);
		String s = m.flowOfHeat();
		System.out.println(s);

	}

}
