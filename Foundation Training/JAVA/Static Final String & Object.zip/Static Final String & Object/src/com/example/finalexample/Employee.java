package com.example.finalexample;

public class Employee /*extends EmployeeHelper

*
*We2 cannot extends/inherit final class
*
*/ 
{

	
	public String name="James";
	public final int id=1;
	
	/*
	 * 
	 * cannot override final method
	 * 
	 * 
	@Override
	public void hello() {
		
	}*/
	
	public void id() {
		//this.id=2; -> I cannot reassign values to final fileds/variables
	}
	
	
	
}
