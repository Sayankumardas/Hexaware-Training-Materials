package com.example.finalexample;

public final class EmployeeHelper {
	
	public final void hello() {
		System.out.println("Hi");
	}

}
