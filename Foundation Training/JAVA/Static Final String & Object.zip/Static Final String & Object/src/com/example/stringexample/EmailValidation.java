package com.example.stringexample;

public class EmailValidation {

	public static void main(String[] args) {
		
		String email = "admin@hexaware.com";
		
		boolean checkEndDot = false;
		checkEndDot = email.endsWith(".");
		
		
		int indexOfAt = email.indexOf("@");
		int lastIndexOfAt = email.indexOf(".");
		int countOfAt=0;
		
		for(int i=0;i<email.length();i++) {
			if(email.charAt(i)=='@')
				countOfAt++;
		}
		
		
		String buffering = email.substring(indexOfAt+1, email.length());
		
		int len = buffering.length();
		
		int countOfDotAfterAt = 0;
		
		for(int i=0;i<len;i++) {
			if(buffering.charAt(i)=='.')
				countOfDotAfterAt++;
		}
		
		String userName = email.substring(0,indexOfAt);
		String domainName = buffering;
		
		
		if((countOfAt==1) && (!userName.endsWith(".")) && (countOfDotAfterAt==1) && ((indexOfAt+3)<=(lastIndexOfAt)) && (!checkEndDot)) {
			System.out.println("Valid Email Address");
		}
		else {
			System.out.println("Invalid email address");
		}
		
		System.out.println("UserName-> "+userName+" DomainName-> "+domainName);
		

	}

}
