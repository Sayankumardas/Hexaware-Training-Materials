package com.example.stringexample;

public class Main {

	public static void main(String[] args) {
		
		
		/*
		 * Strings are immutable
		 * */
		
		String s1 = "abc";
		s1="xyz";
		
		System.out.println(s1);
		
		/*How are string immutable?
		because we cannot change the internal structure of the string
		
		s1.charAt(0)='j'; //-> This will throw error
		
		*/
		
		s1 = s1+"abc";
		System.out.println(s1);
		
		
		//Ways of creating string
		String s2 = "abc";
		String s3 = new String("abc");
		String s4 = "abc";
		
		System.out.println((s2==s3)); // in == address is compared, since we have used new keyword so it has created a separate object
		System.out.println((s2==s4));
		/*Best Way to compare Strings*/
		System.out.println(s2.equals(s3)); // .equals checks the values not the address
		
		
		/*
		 * Examples of StringBuilder
		 * */
		
		StringBuilder sb = new StringBuilder();
		sb.append("Hello Worlld");
		System.out.println(sb.indexOf("ll")); //it print the index of first-occurence
		System.out.println(sb.substring(0,3).toString());
		System.out.println(sb.reverse().toString());
		
		
		/*
		 * TODO: Write examples of StringBuffer
		 * 
		 * */
		
		
	}

}
