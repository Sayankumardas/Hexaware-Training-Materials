package com.example.staticexample.innerclass;

public class CompanyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//Static methods & classes
		Company.hello();
		
		Company.Employee.hello();
		
		//Non-static methods
		
		Company.Employee emp = new Company.Employee();
		emp.companyName();

	}

}
