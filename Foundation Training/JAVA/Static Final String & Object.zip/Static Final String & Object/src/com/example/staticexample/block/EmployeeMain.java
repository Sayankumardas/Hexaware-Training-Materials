package com.example.staticexample.block;

import java.util.Date;

public class EmployeeMain {
	
	/*
	 * Before Employee class method is executed I want certain set of instructions to be printed/executed
	 * 
	 * Static blocks are executed in the order in which they are written
	 * */
	static int a;
	
	static {
		System.out.println("Opening Created");
		System.out.println("Interview Conducted");
	}
	
	static {
		Date date = new Date();
		System.out.println("Date Of Joining: "+date);
	}
	
	static {
		 int b=10; //these are local variables for this static block
		 final int c=10;
		 a=b; //can be used to initialize static variables
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee.helloEmployee();
		
		System.out.println(EmployeeMain.a);
		
		

	}

}
