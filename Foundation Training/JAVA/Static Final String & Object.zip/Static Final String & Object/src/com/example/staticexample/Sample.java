package com.example.staticexample;

public class Sample {
	
	public static void display() {
		System.out.println("Display Sample");
	}
	
	public void hello() {
		System.out.println("Sample Hello World");
	}

}
