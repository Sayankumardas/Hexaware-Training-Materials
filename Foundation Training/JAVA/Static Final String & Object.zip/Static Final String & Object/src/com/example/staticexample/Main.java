package com.example.staticexample;

/*
 * Static variables can be access directly inside a static method(means without using class name) if those are within same class
 * Static methods can be directly accessed inside static methods(means without using class name) if those are within same class
 * */



public class Main {

	private int a=5;
	private static int b=10; //static/class variable
	private final int c=15; //I cannot change the value
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Static variables
		System.out.println(Main.b);
		System.out.println(b);
		
		Main main = new Main();
		System.out.println(main.a);
		
		//Static method-> by using class name
		display();
		Main.display();
		
		Sample.display();//since they are in different classes
		
		
		//non-static methods-> by declaring objects
		main.hello();
		
		Sample smp = new Sample();
		smp.hello();
		
	}
	
	public void hello() {
		System.out.println("Hello World");
	}
	
	public static void display() {
		System.out.println("Static Method");
	}

}
