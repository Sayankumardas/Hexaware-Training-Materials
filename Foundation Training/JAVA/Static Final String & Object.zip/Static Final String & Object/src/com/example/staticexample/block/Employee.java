package com.example.staticexample.block;

public class Employee {
	
	public static void helloEmployee() {
		System.out.println("Welcome To Company");
	}

}
