package com.example.staticexample.innerclass;

public class Company {
	
	private static String name = "XYZ";
	
	//Inner class
	static class Employee{
		
		public static void hello() {
			System.out.println("Employee hello");
		}
		
		public void companyName() {
			System.out.println("Employee Works in "+name+" Company.");
		}
	}
	
	
	public static void hello() {
		System.out.println("Company Hello");
	}

}
