print("Hello World")
print('''Hi''')

def sum(a,b):
	return a+b


print(sum(2,5))
