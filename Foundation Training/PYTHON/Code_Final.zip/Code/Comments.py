#This is single line comment


#Line 1
#Line 2
#Line 3


"""
This is an example of docsctring comment

"""


a = """

docstring value

"""


print(a)
print(type(a))