import math

#type-casting
x="120.2"
#print(int(x))
print(float(x))
print(complex(x))

#calculations
print(math.sqrt(120))
#print(math.sqrt(120+5j)) -> we cannot square-root a complex number
print(math.floor(10.9))
print(math.ceil(10.9))
print(math.pow(2,5)) #returns type float
print(math.e)
print(math.pi)