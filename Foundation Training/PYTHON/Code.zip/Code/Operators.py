#Aritematic Operators
a=3
b=5

print(a+b)
print(a-b)
print(a*b)
print(b/a)

c=10001
d=101

print(c/d)
print(c//d) #Floor function -> the lowest integer value eg: 12.12333 -> 12

print(a**b) # a^b


#Conditional Operators
a=3
b=5


print(a<b)
print(a>b)
print(a<=b)
print(a>=b)
print(a==b)
print(a!=b)

#logical Operators

price=9.99

print(price>9 and price<10)
print(price>9 or price<10)
print(not price>10)